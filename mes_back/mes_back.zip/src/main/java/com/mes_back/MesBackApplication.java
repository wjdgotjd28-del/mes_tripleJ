package com.mes_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class
MesBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(MesBackApplication.class, args);
	}

}
