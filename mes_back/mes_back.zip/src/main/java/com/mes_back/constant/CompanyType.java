package com.mes_back.constant;

public enum CompanyType {
    CUSTOMER, PURCHASER
    //거래처, 매입처
}
