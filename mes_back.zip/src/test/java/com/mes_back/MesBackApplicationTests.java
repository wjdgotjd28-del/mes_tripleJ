package com.mes_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MesBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
