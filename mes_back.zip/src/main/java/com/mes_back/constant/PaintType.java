package com.mes_back.constant;

public enum PaintType {
    POWDER,LIQUID
}
