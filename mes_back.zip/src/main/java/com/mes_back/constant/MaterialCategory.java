package com.mes_back.constant;

public enum MaterialCategory {
    PAINT,THINNER,CLEANER,HARDENER
    //'페인트', '신나', '세척제', '경화제'
}
