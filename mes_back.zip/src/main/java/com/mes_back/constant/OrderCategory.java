package com.mes_back.constant;

public enum OrderCategory {
    DEFENSE,GENERAL,AUTOMOTIVE,SHIPBUILDING
    //방산,일반,자동차,조선
}
